import React from "react"

export default function socketTest() {
    // const host = "127.168.0.29"
    const host = "127.0.0.1"
    const port = 4000
    let ws = undefined

    const socketStart = () => {
        if(ws === undefined){
            ws = new WebSocket("ws://"+host+":"+port+"/ws");
            ws.onopen = () => {
              console.log("connected!!");
            };
            ws.onmessage = (message) => { //server to client
              console.log("message", message);
            };
            ws.onclose = function(){
                ws = undefined
                console.log("Server Disconnect..")
            };
            ws.onerror = function(message){
                console.log("error..")
            };
        }
    }

    const socketStop = () => {
        if(ws !== undefined){
            ws.close();
            console.log('close')
        }
    }
    
    const socketSend = () => { 
        if(ws !== undefined){
            ws.send("hello this is client Message"); //client to server
        }
    }
    
    return(
        <div>
            <button onClick={socketStart}>소켓 시작</button>
            <button onClick={socketStop}>소켓 종료</button>
            <button onClick={socketSend}>소켓 전송</button>
        </div>
    )
}
