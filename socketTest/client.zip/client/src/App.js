import React from 'react'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import SocketTest from './socket/socketTest'

const App = () => {
  return (
    <Router>
      <Routes>
        {/* <Route path='/' component={SocketTest} /> */}
        <Route path="/" element={<SocketTest />}></Route>
      </Routes>
    </Router>
  )
}

export default App